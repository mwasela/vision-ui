import ProLayout from "@ant-design/pro-layout";
import { useState, useEffect } from "react";
import axios from "../helpers/axios";
import { useNavigate, Outlet } from "react-router-dom";
import bslogo from  "../Images/bslogo.png"
import { AimOutlined, UserOutlined, TruckOutlined, LogoutOutlined } from "@ant-design/icons";
import { Link } from "react-router-dom";
import { Dropdown, Menu } from "antd";





export default function MainLayout() {

    const [user_id, setUser_id] = useState(null);
    const [user, setUser] = useState(null);
    //const [location, setLocation] = React.useState({ pathname: _location.pathname });

    const getUser = () => {
        const request = axios.get("/users/current");
        request.then((response) => {
            setUser_id(response.data.user_.blk_users_status);
            setUser(response.data);
            console.log("User", response.data);
            return response;
        }).catch((error) => {
            console.log(error);
        });

    }
    useEffect(() => {
        getUser();
    }, []);

    const items = [
        {
            key: "logout",
            label: "Log-out",
            icon: <LogoutOutlined />,
            danger: true,
            onClick: () => {
                navigate("/login");
            },
        },
    ];


    const navigate = useNavigate();
    const token = localStorage.getItem("token");
    useEffect(() => {
        if (!token) {
            navigate("/login");
        }
    }, [token, navigate]);

    return (
        <ProLayout
            logo={bslogo}
            layout="mix"
            title="BSL Vision - AI Counter"
            location={location}
            avatarProps={{
                alt: "avatar",
                src: "https://gw.alipayobjects.com/zos/antfincdn/efFD%24IOql2/weixintupian_20170331104822.jpg",
                title: user?.user_.blk_users_surname + " " + user?.user_.blk_users_fname,
                render: (_, children) => {
                    return <Dropdown menu={{ items }}>{children}</Dropdown>;
                },
            }}
            //render a prop with profile data
            
            // menuItemRender={(item, dom) => <Link to={item.path} onClick={()=>{
            //     setLocation({pathname: item.path});
            //   }}>{dom}</Link>}
            //   avatarProps={{
            //     src: "https://avatars.githubusercontent.com/u/8186664?s=460&v=4",
            //     title: user?.mgr_wrkpersonnels_fname+" "+user?.mgr_wrkpersonnels_surname,
            //     render: (_, avatarChildren) => {
            //       return <AvatarDropdown>{avatarChildren}</AvatarDropdown>;
            //     },
            //   }}
              
            route={{
                routes: [
                    {
                        path: "/",
                        name: "Home",
                        icon: <AimOutlined />,
                        component: "Home",
                    },
                    {
                        path: "/Stats",
                        name: "Statistics",
                        icon: <UserOutlined />,
                        component: "Drivers",
                    },
                    {
                        path: "/Register",
                        name: "Regsiter",
                        icon: <UserOutlined />,
                        component: "Register",
                    },
                    {
                        path: "/login",
                        name: "Logout",
                        icon: <LogoutOutlined />,
                        component: "Login",
                    }
                ],
            }}
            menuItemRender={(item, dom) => <Link to={item.path} onClick={()=>{
                navigate(item.path);
              }}>{dom}</Link>}

        >
            <Outlet />
        </ProLayout>
    );


}
