import axios from "axios";
import { BASE_URL } from '../constants/index.jsx'; 


const instance = axios.create({
    baseURL: BASE_URL
});


//check token return error if not found
instance.interceptors.request.use(function (config) {
    // Add authorization header if token exists in localStorage
    if(localStorage.getItem('token')){
        config.headers.Authorization = `Bearer ${localStorage.getItem('token')}`;
    }
    return config;
}, function (error) {
    // Handle request error
    return Promise.reject(error);
});

instance.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response && error.status === 403 || error.status === 401) {

            window.location.href = '/login';
          
        }
        return Promise.reject(error)
    },
)

export default instance

//if status.response is 401 or 403 navigate to login



    