import { createBrowserRouter } from "react-router-dom";
import MainLayout from "./Layouts/MainLayout";
import Stats from "./Pages/Stats";
import Home from "./Pages/Home";
import Login from "./Pages/Auth/Login";
import { Layout } from "antd";
import Register from "./Pages/Auth/Register";



const router = createBrowserRouter([
    {
      path: "/",
      element: <MainLayout />,
      children: [
        
        { path: "/", element: <Home /> },
        { path: "/Stats", element: <Stats /> },
        { path: "/Register", element: <Register />}
      ],
    },
    {path: "/login", element: <Layout><Login /></Layout>},
  ]);
  

  export default router;