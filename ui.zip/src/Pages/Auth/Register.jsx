import React from 'react'
import { ProForm, ProFormText, LoginForm, ProFormSelect} from '@ant-design/pro-form';
import axios from '../../helpers/axios';
import { notification } from 'antd';



export default function Register() {
  return (
    <div>
      <LoginForm
        subTitle="Register New User"
        onFinish={async (values) => {
          console.log(values);
          try {
            const response = await axios.post('/users/register', values);
            console.log(response);
            notification.success({
              message: "Registration Successful",
              description: response.data.message,
            });
            // navigation("/login", { replace: true });
          } catch (error) {
            console.log(error);
            notification.error({
              message: "Registration Failed",
              description: error.response?.data?.message || "An error occurred",
            });
          }
        }}

        submitter={{
          searchConfig: {
            submitText: 'Register',
          },
        }}
      >

        <ProFormText
          name="fname"
          label="First Name"
          placeholder="Enter your name"
          rules={[{ required: true, message: 'Please enter your name' }]}
        />
        <ProFormText
          name="surname"
          label="Surname"
          placeholder="Enter your surname"
          rules={[{ required: true, message: 'Please enter your surname' }]}
        />
        <ProFormText
          name="email"
          label="Email"
          placeholder="Enter your email"
          rules={[{ required: true, message: 'Please enter your email' }]}
        />
        <ProFormSelect
          name="type"
          label="Role"
          placeholder="Select your role"
          options={[
            {
              value: '1',
              label: 'Admin',
            },
            {
              value: '2',
              label: 'User',
            },
          ]}
          rules={[{ required: true, message: 'Please select your role' }]}

        />

        <ProFormText.Password
          name="password"
          label="Password"
          type="password"

          placeholder="Enter your password"
          rules={[{ required: true, message: 'Please enter your password' }]}
        />
{/* 
        <ProFormText.Password
          name="confirm"
          label="Confirm Password"
          type="password"
          placeholder="Confirm your password"
          rules={[{ required: true, message: 'Please confirm your password' }]}
        /> */}


      </LoginForm>
    </div>
  )
}
