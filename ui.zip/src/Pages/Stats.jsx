import React, { PureComponent } from 'react'

export default class Stats extends PureComponent {
  render() {
    return (
      <div>Stats</div>
    )
  }
}
