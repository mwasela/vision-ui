import React, { useEffect, useRef, useState } from 'react';
import mpegts from 'mpegts.js';
import { ProCard } from '@ant-design/pro-card';
import { ProFormText, ProFormGroup, ProForm, ProFormSelect } from '@ant-design/pro-form';
import { ProTable } from '@ant-design/pro-table';
import conveyor from '../Images/conveyor.png';
import { Button, Row, Col } from 'antd';
import axios from 'axios';
import conveyors from '../Images/conveyors.gif';

const BASE_URL = "http://192.168.3.38:3010/api/predelivery/v1";
const TRACK_URL = "http://localhost:5000/track-ids";
const RESET_URL = "http://localhost:5000/reset-tracker";
const API_URL = "http://localhost:3000";


export default function Home() {

  const [beltstate, setBeltState] = useState('Stopped');
  const [belt2state, setBelt2status] = useState('Stopped');
  const [deliverydetails, setDeliveryDetails] = useState(null);
  const [selectedBelt, setSelectedBelt] = useState(null);
  const [atl, setAtl] = useState(null);
  const [belt1count , setBelt1Count] = useState('--');
  const [belt2count , setBelt2Count] = useState('--');
  const [belt1target , setBelt1Target] = useState('');
  const [belt2target , setBelt2Target] = useState('');




useEffect(() => {
  if (belt1count === belt1target) {
    setBeltState('Stopped');
    saveTransaction();
  }
  fetchBelt1Count();
}, []);

  const fetchBelt1Count = async () => {
    
    try {
      const response = await axios.get(TRACK_URL);
      //console.log("belt 1 count", response.data);
      displayOne(response.data);
      fetchBelt1Count();
    } catch (error) {
      console.log(error);
    }
  }
  fetchBelt1Count();

  const saveTransaction = async () => {

    console.log("transaction saved");
    // try {
    //   const response = await axios.post(API, { data: deliverydetails });
    //   console.log("transaction saved", response);
    // } catch (error) {
    //   console.log(error);
    // }
  }

  const displayOne = (data) => {
    //console.log("display one", data.track_ids);
    if (data.track_ids.length > 0) {
      setBelt1Count(data.track_ids[0]);
    }

  }


  const ResetBeltone = async () => {
    try {
      const req = await axios.get(RESET_URL);
      console.log("reset", req);
    }catch (error) {
      console.log(error);
    }
  }
  

  const ResetBelttwo = async () => {
    console.log("reset belt 2");
    // try {
    //   const req = await axios.get(RESET_URL);
    //   console.log("reset", req);
    // }catch (error) {
    //   console.log(error);
    // }
  }


  const fetchDeliveryDetails = async () => {
    //fetch delivery details
    try {
      const response = await axios.post(BASE_URL, { ordernumber: atl });
      //console.log("delivery", response.data);
      setDeliveryDetails(response.data);
      setSelectedBelt(response.data[0].LANE);
      setBelt1Target(response.data[0].Target);
    } catch (error) {
      console.log(error);
    }
    //setDeliveryDetails(response.data);
  }
  
  const beltStatus = async (belt) => {

    if (belt === 'LANE-111B') {
      ResetBeltone();
      setBeltState('running');
      console.log("belt 1 running");
    }
    else if (belt === 'LANE-112B') {
      ResetBelttwo();
      setBelt2status('running');
      console.log("belt 2 running");
    }
  }



  const startloading = (deliverydetails) => {
    beltStatus(selectedBelt);
   
  }


  return (

    <>
      <div>
        <ProCard
          title="Truck Load - Details"
          style={{
            width: "100%",
            height: "auto",
            // position: "absolute",
            paddingTop: "20px",
          }}
        >
          <ProForm
            //inline
            layout="inline"
            submitter={{
              searchConfig: {
                submitText: "Search",
                //style
                style: {
                  marginLeft: '10px',
                }

              },
              //hide reset
              resetButtonProps: {
                style: {
                  display: 'none',
                },
              },
              onSubmit: (values) => {
                fetchDeliveryDetails();
              }
              ,
              //button inline
              render: (_, dom) => dom.pop(),
              submitButtonProps: {
                style: {
                  alignContent: 'right',

                },
              },

            }}
          >

            <ProForm.Group >
              <ProFormText
                name="order_no"
                label="Search"
                placeholder="Enter Trailer Name"
                onChange={(value) => setAtl(value.target.value)}
                fieldProps={{
                  size: "small",
                }}
              />
              {/* <ProFormSelect
                name="belt"
                label="Select Belt"
                placeholder="Select Belt"
                fieldProps={{
                  size: "small",
                }}
                onChange={(value) => setSelectedBelt(value)}
                options={[
                  {
                    value: "1",
                    label: "Line 1",
                  },
                  {
                    value: "2",
                    label: "Line 2",
                  }
                ]}
              /> */}
            </ProForm.Group>
          </ProForm>


        </ProCard>

     { deliverydetails && 
      
      
       <ProCard
          title="Delivery Details"
          style={{

            width: "100%",
            height: "auto",
            // position: "absolute",
            paddingTop: "20px",
            marginTop: "20px",
          }}
        >
          Order No: {deliverydetails[0]?.Ordernumber?? "Unkown"} <br />
          Truck No: {deliverydetails[0]?.Truck?? "Unkown"} <br />
          Trailer No: {deliverydetails[0]?.Trailler ?? "Unkown"} <br />
          Driver: {deliverydetails[0]?.Driver ?? "Unkown"} <br />
          Product: {deliverydetails[0]?.Product ?? "Unkown" } <br />
          Packing: {deliverydetails[0]?.Packing ?? "Unkown"} <br />
          Target: {deliverydetails[0]?.Target ?? "Unkown"} <br />
          Belt: {deliverydetails[0]?.LANE ?? "Unknown"} <br />
          {/* <Button type="primary" onClick={startloading(deliverydetails)}>Refresh</Button> */}
          <Button 
          type="primary"
          onClick={() => 
            startloading(deliverydetails)}
          style={{marginTop: '10px'}}
          
          >Start Loading</Button>
        </ProCard>
}

        <Row gutter={[10, 10]}>
          <Col md={6} sm={24} xs={24}>
          <ProCard
            title="Bag Count - Belt 1"
            style={{
              width: "100%",
              height: "auto",
              //paddingTop: "15px",
              marginTop: "20px",
            }}
          >
                 <h1
              style={{
                color: "black",
                fontSize: "50px",

              }}
            > {belt1count} </h1>
            <Button type="primary" onClick={ResetBeltone}>Reset</Button>
          </ProCard>
          </Col>
          <Col md={6} sm={24} xs={24}>
          <ProCard
            title="Line 1"
            subTitle="Belt Status"
            style={{
              width: "100%",
              height: "auto",
              // position: "absolute",
              color: belt2state === "running" ? "green" : "red",
              paddingTop: "20px",
              marginTop: "20px",
              
            }}
          >
          
            <img src={beltstate === "running" ? conveyors : conveyor } alt="conveyor" style={{ width: "100px", height: "auto", marginBottom: '10px' }} />
            <br />

            {beltstate} <br/>
            <h3>Target: {belt1target}</h3>
          </ProCard>  
          </Col>
          <Col md={6} sm={24} xs={24}>
          <ProCard
            title="Line 2"
            subTitle="Belts Status"
            style={{

              width: "100%",
              height: "auto",
              color: belt2state === "running" ? "green" : "red",
              paddingTop: "20px",
              marginTop: "20px",
            }}
          >  
            <img src={belt2state === "running" ? conveyors : conveyor } alt="conveyor" style={{ width: "100px", height: "auto", marginBottom: '10px' }} />
            <br /> 
           
            {belt2state}<br/>
            <h3>Target: {belt2target}</h3>
             
          </ProCard>

          </Col>
          <Col md={6} sm={24} xs={24}>
          <ProCard
            title="Bag Count - Belt 2"
            style={{
              width: "100%",
              height: "auto",
              // position: "absolute",
              //paddingTop: "15px",
              marginTop: "20px",
            }}
          >
            <h1
              style={{
                color: "black",
                fontSize: "50px",

              }}
            > {belt2count  }</h1>
          <Button type="primary" onClick={ResetBelttwo}>Reset</Button>
          </ProCard>
          </Col>

          </Row>

      </div>


      <ProTable
        style={{
          width: "100%",
          height: "auto",
          marginTop: "20px",
        }}
        search={false}

        headerTitle="Truck Load - Details"
        columns={[
          {
            title: 'Truck No',
            dataIndex: 'truck_no',
            key: 'truck_no',
          },
          {
            title: 'Trailer No',
            dataIndex: 'trailer_no',
            key: 'trailer_no',
            valueEnum: {
              1: 'KBD 473H',
              2: 'KBF 574H',
              3: 'KBS 435H',
            }
          },

          {
            title: 'Driver',
            dataIndex: 'driver',
            key: 'driver',
          },
          {
            title: 'Belt',
            dataIndex: 'belt',
            key: 'belt',
            valueEnum: {
              1: 'Line 1',
              2: 'Line 2',
            },
          },
          {
            title: 'Product',
            dataIndex: 'product',
            key: 'product',
          },
          {
            title: 'Date',
            dataIndex: 'date',
            key: 'date',
          },
        ]}
        request={async (params, sorter, filter) => {
          console.log(params, sorter, filter);
          return {
            data: [
              {
                truck_no: '1',
                trailer_no: '1',
                driver: 'John Doe',
                belt: '1',
                product: 'Fertilizer NPK 17-17-17',
                date: '2024-07-01',
              },
              {
                truck_no: '2',
                trailer_no: '2',
                driver: 'Jane Doe',
                belt: '2',
                product: 'DAP Fertilizer',
                date: '2024-07-07',
              },
            ],
            success: true,
          };
        }
        } />



    </>
  );
}