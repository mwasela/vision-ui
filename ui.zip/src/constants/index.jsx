const BASE_URL = "http://localhost:3000";
export { BASE_URL };
