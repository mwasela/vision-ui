const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('blk_bsldriver', 'root', '12345', {
  host: 'localhost',
  dialect: 'mysql',
});

module.exports = sequelize;
