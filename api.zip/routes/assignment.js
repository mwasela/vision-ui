var express = require('express');
var router = express.Router();
const Truck = require('../models/Truck');
const Driver = require('../models/Driver');
const Assignment = require('../models/Assignment');
const authenticateToken = require('../middlewares/auth');


Assignment.belongsTo(Truck, { foreignKey: 'mgr_assignments_truck_id' });
Assignment.belongsTo(Driver, { foreignKey: 'mgr_assignments_driver_id' });

//get all assignments
router.get('/', authenticateToken, async (req, res) => {
    try {
        const assignments = await Assignment.findAll({
                include: [
                    {
                        model: Truck
                    },
                    {
                        model: Driver
                    },
                ]

        });
        return res.status(200).json({ assignments });
    } catch (err) {
        console.log(err);
        return res.status(500).json({ message: err.message });
    }
});


router.post('/', authenticateToken, async (req, res) => {

    const { mgr_id, truck_id, driver_id } = req.body;
    try {
        const assignment = await Assignment.create({
            mgr_id,
            truck_id,
            driver_id
        });
        return res.status(200).json({ assignment });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});


router.put('/:id', authenticateToken, async (req, res) => {

    const { mgr_id, truck_id, driver_id } = req.body;
    try {
        const assignment = await Assignment.update({
            mgr_id,
            truck_id,
            driver_id
        }, {
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ assignment });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});



module.exports = router