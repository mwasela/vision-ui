var express = require('express');
var router = express.Router();
const Driver = require('../models/Driver');
const authenticateToken = require('../middlewares/auth');


//CRUD

//get all drivers
router.get('/', authenticateToken, async (req, res) => {
    try {
        const drivers = await Driver.findAll();
        return res.status(200).json({ drivers });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});

//get driver by id
router.get('/:id', authenticateToken, async (req, res) => {
    try {
        const driver = await Driver.findOne({
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ driver });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});


//post driver
router.post('/', authenticateToken, async (req, res) => {
    
    const { mgr_driver_name, mgr_driver_status } = req.body;
    try {
        const driver = await Driver.create({
            mgr_driver_name,
            mgr_driver_status
        });
        return res.status(200).json({ driver });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});

//put driver by id
router.put('/:id', authenticateToken, async (req, res) => {
    const { mgr_driver_name, mgr_driver_status } = req.body;
    try {
        const driver = await Driver.update({
            mgr_driver_name,
            mgr_driver_status
        }, {
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ driver });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});


//delete driver by id
router.delete('/:id', authenticateToken, async (req, res) => {
    try {
        const driver = await Driver.destroy({
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ driver });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}); 

module.exports = router;
