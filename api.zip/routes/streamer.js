const express = require('express');
const router = express.Router();
const Stream = require('node-rtsp-stream');





router.get('/start', (req, res) => {

    //enable cors

    

    const stream = new Stream({
      name: 'rtspStream',
      streamUrl: 'rtsp://admin:abc12345@10.168.8.199:554/sub',
      wsPort: 9999, // WebSocket port
      ffmpegOptions: { // Options for ffmpeg
        '-stats': '', // an option with no neccessary value uses a blank string
        '-r': 24, // 30 fps
      }
    });
    res.header("Access-Control-Allow-Origin", "*");
    res.send('Stream started');

  });


 module.exports =  router;