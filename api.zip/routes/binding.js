var express = require('express');
var router = express.Router();
var Binding = require('../models/Binding');
const authenticateToken = require('../middlewares/auth');
const Driver = require('../models/Driver');
const Truck = require('../models/Truck');


//binding belongs to drivers and trucks

Binding.belongsTo(Driver, { foreignKey: 'mgr_bindings_driver_id' });
Binding.belongsTo(Truck, { foreignKey: 'mgr_bindings_truck_id' });  

//CRUD
router.get('/', authenticateToken, async (req, res) => {
    try {
        const bindings = await Binding.findAll({
            include: [
                {
                    model: Driver
                },
                {
                    model: Truck
                },
            ]
        });
        return res.status(200).json({ bindings });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});


router.get('/truck', authenticateToken, async (req, res) => {
    
    const truck = req.query.truck;
    console.log(truck);

    try{
        const binding = await Binding.findAll({
            where: {
                mgr_bindings_truck_id: truck,
            },
            include: [
                {
                    model: Driver
                }
            ]
    });
    return res.status(200).json({ binding });
    } catch (err) {
        return res.status(500).json({ message: err.message });

    }
});   


router.get('/:id', authenticateToken, async (req, res) => {
    try {
        const binding = await Binding.findOne({
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ binding });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});

router.post('/', authenticateToken, async (req, res) => {   
    const { emp_id, mgr_id } = req.body;
    try {
        const binding = await Binding.create({
            emp_id,
            mgr_id
        });
        return res.status(200).json({ binding });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});

router.put('/:id', authenticateToken, async (req, res) => {
    const { emp_id, mgr_id } = req.body;
    try {
        const binding = await Binding.update({
            emp_id,
            mgr_id
        }, {
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ binding });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});


router.delete('/:id', authenticateToken, async (req, res) => {
    try {
        const binding = await Binding.destroy({
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ binding });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});


module.exports = router;