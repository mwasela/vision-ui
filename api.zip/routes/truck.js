var express = require('express');
var router = express.Router();
const Truck = require('../models/Truck');
const authenticateToken = require('../middlewares/auth');



//CRUD for trucks

//get all trucks
router.get('/', authenticateToken, async (req, res) => {
    try {
        const trucks = await Truck.findAll();
        return res.status(200).json({ trucks });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});

//get truck by id
router.get('/:id', authenticateToken, async (req, res) => {
    try {
        const truck = await Truck.findOne({
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ truck });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});

//post trucks

router.post('/', authenticateToken, async (req, res) => {
    const { mgr_truck_plate, mgr_truck_status } = req.body;
    try {
        const truck = await Truck.create({
            mgr_truck_plate,
            mgr_truck_status
        });
        return res.status(200).json({ truck });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});


//put truck by id
router.put('/:id', authenticateToken, async (req, res) => {
    const { mgr_truck_plate, mgr_truck_status } = req.body;
    try {
        const truck = await Truck.update({
            mgr_truck_plate,
            mgr_truck_status
        }, {
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ truck });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});


//delete truck by id
router.delete('/:id', authenticateToken, async (req, res) => {
    try {
        const truck = await Truck.destroy({
            where: {
                id: req.params.id
            }
        });
        return res.status(200).json({ truck });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
});


module.exports = router;