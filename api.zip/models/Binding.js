const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Truck = require('./Truck');
const Driver = require('./Driver'); 


const Binding = sequelize.define('bindings', {
    id : {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mgr_bindings_truck_id: {
        type: DataTypes.INTEGER,
        references: { model: Truck, key: 'id' },

    },
    mgr_bindings_driver_id: {
        type: DataTypes.INTEGER,
        references: { model: Driver, key: 'id' },
    },
    mgr_bindings_status: {
        type: DataTypes.INTEGER
    },

}, {
    timestamps: false
});


//Track and driver are belonging to one binding

Binding.belongsTo(Truck, { foreignKey: 'mgr_bindings_truck_id' });
Binding.belongsTo(Driver, { foreignKey: 'mgr_bindings_driver_id' });

sequelize
  .sync({
    //force: true
  })
  .then(() => {
    console.log("Models synced with the database");
  })
  .catch((error) => {
    console.error("Error syncing models:", error);
  });



module.exports = Binding;