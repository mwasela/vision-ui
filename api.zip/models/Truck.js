const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Truck = sequelize.define('trucks', {
    id : {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mgr_truck_plate: {
        type: DataTypes.STRING
    },
    mgr_truck_status: {
        type: DataTypes.INTEGER
    },

}, {
    timestamps: false
});

sequelize
  .sync({
    //force: true
  })
  .then(() => {
    console.log("Models synced with the database");
  })
  .catch((error) => {
    console.error("Error syncing models:", error);
  });


module.exports = Truck;