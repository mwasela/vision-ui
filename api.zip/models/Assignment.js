const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Truck = require('./Truck');
const Driver = require('./Driver');


const Assignment = sequelize.define('assignment', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    mgr_assignments_truck_id: {
        type: DataTypes.INTEGER
    },
    mgr_assignments_driver_id: {
        type: DataTypes.INTEGER
    },
    mgr_assignments_date: {
        type: DataTypes.DATE
    },
    mgr_assignments_status: {
        type: DataTypes.INTEGER
    },
}, {
    timestamps: false
});

//truck is from truck table so is driver from driver table


Assignment.belongsTo(Truck, { foreignKey: 'mgr_assignments_truck_id' });
Assignment.belongsTo(Driver, { foreignKey: 'mgr_assignments_driver_id' });

sequelize
  .sync({
    //force: true
  })
  .then(() => {
    console.log("Models synced with the database");
  })
  .catch((error) => {
    console.error("Error syncing models:", error);
  });


module.exports = Assignment;


