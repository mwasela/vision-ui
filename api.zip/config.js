module.exports = {
    secretKey: "7OpydV8O7eheeZYtznE1lxfdddve34a42d2sa25vg553hkd73okdjnnfd",
  };
